package com.hospital.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import com.hospital.model.Patient;

public class PatientDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/hospital_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "password";

    public boolean registerPatient(Patient patient) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String sql = "INSERT INTO patients (name, age, gender, contact, address, linkedin) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, patient.getName());
            stmt.setInt(2, patient.getAge());
            stmt.setString(3, patient.getGender());
            stmt.setString(4, patient.getContact());
            stmt.setString(5, patient.getAddress());
            stmt.setString(6, patient.getLinkedin());

            int rowsInserted = stmt.executeUpdate();
            conn.close();

            return rowsInserted > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
